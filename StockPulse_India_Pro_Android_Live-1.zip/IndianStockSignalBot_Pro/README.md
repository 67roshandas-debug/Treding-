# StockPulse India — Android app
Reads live signals from the StockPulse backend (server.py, Angel One data) every 5 seconds.
1. Run the backend and confirm http://YOUR_SERVER:8000/signals shows real data.
2. Open app/src/main/java/com/roshan/stocksignal/MainActivity.kt and set API_URL to your server address.
   - Phone on the same Wi-Fi as your PC: http://<PC-local-IP>:8000/signals
   - Android emulator to your PC: http://10.0.2.2:8000/signals
   - Anywhere: host the backend on a server with HTTPS and use https://... (then remove usesCleartextTraffic in AndroidManifest.xml)
3. Build in Android Studio: Build > Build APK(s).
Credentials (Angel One PIN, TOTP, API key) stay on the server. They are never stored in the app.
