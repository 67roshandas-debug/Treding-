package com.roshan.stocksignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

// >>> Put your server's address here (the machine running server.py). Use https:// for anything beyond testing.
const val API_URL = "http://YOUR_SERVER_IP:8000/signals"
const val REFRESH_MS = 5000L

private val Navy = Color(0xFF060D18); private val Panel = Color(0xFF0F1A2B); private val Panel2 = Color(0xFF142238)
private val Line = Color(0xFF22334B); private val Green = Color(0xFF1FD693); private val Red = Color(0xFFFF5C6C)
private val Amber = Color(0xFFFFB020); private val Muted = Color(0xFF8093AB); private val Blue = Color(0xFF5B9BFF)

data class Signal(val s: String, val d: String, val e: Double, val sl: Double, val t: Double, val p: Double, val sc: Int, val w: List<String>)
data class Idx(val v: Double, val o: Double, val h: List<Double>)
data class Feed(val status: String, val source: String?, val note: String?, val error: String?, val updated: Long,
                val signals: List<Signal>, val nifty: Idx?, val bank: Idx?)

private fun JSONObject.str(k: String): String? = if (isNull(k)) null else getString(k)
private fun idx(o: JSONObject?): Idx? = o?.let {
    val h = it.optJSONArray("h")
    Idx(it.getDouble("v"), it.getDouble("o"), List(h?.length() ?: 0) { i -> h!!.getDouble(i) })
}

fun fetchFeed(): Feed {
    val c = URL(API_URL).openConnection() as HttpURLConnection
    c.connectTimeout = 5000; c.readTimeout = 5000
    val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    val arr = j.getJSONArray("signals")
    val sigs = List(arr.length()) { i ->
        val o = arr.getJSONObject(i); val w = o.optJSONArray("w")
        Signal(o.getString("s"), o.getString("d"), o.getDouble("e"), o.getDouble("sl"), o.getDouble("t"),
            o.optDouble("p", o.getDouble("e")), o.optInt("sc"), List(w?.length() ?: 0) { k -> w!!.getString(k) })
    }
    val ix = j.optJSONObject("indices")
    return Feed(j.getString("status"), j.str("source"), j.str("note"), j.str("error"), System.currentTimeMillis(),
        sigs, idx(ix?.optJSONObject("n")), idx(ix?.optJSONObject("b")))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App() } }
}

@Composable fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var feed by remember { mutableStateOf<Feed?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            try { feed = withContext(Dispatchers.IO) { fetchFeed() }; err = null }
            catch (e: Exception) { err = "Cannot reach server: ${e.message}" }
            delay(REFRESH_MS)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Navy, surface = Panel, onSurface = Color.White)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home" to "⌂", "Signals" to "↗", "Checks" to "⌕", "Stats" to "▥").forEachIndexed { i, (t, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(ic, fontSize = 20.sp) }, label = { Text(t, fontSize = 10.sp) })
                }
            }
        }) { p ->
            LazyColumn(Modifier.padding(p).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Header(feed, err) }
                item { IndexRow(feed?.nifty, feed?.bank) }
                item { Bias(feed?.nifty) }
                when (tab) {
                    0, 1 -> {
                        item { Text(if (tab == 0) "TOP SIGNALS" else "ALL QUALIFIED SIGNALS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        val list = feed?.signals.orEmpty().let { if (tab == 0) it.take(2) else it }
                        if (list.isEmpty()) item { Panelled { Text(if (feed == null) "Waiting for data…" else "No trade. No setup passes every check right now.", color = Muted) } }
                        items(list, key = { it.s + it.d }) { SignalCard(it) }
                    }
                    2 -> items(listOf("NSE liquidity filter", "NIFTY + sector trend", "Liquidity sweep / BOS / CHOCH", "VWAP + EMA confirmation",
                        "Relative volume", "Minimum 1:2 R:R", "Reject conflicting setups")) { Panelled { Text("✓  $it") } }
                    else -> item { Panelled { Column {
                        Text("Validation required", color = Green, fontWeight = FontWeight.Bold)
                        Text("A 70% win rate is a goal, not a guarantee. Back-test and out-of-sample test to measure real results.", Modifier.padding(vertical = 8.dp))
                        Text("Track: win rate • profit factor • drawdown • average R:R • trade count", color = Muted, fontSize = 12.sp)
                    } } }
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}

@Composable fun Panelled(content: @Composable () -> Unit) =
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Box(Modifier.padding(14.dp)) { content() } }

@Composable fun Header(feed: Feed?, err: String?) {
    val (label, color) = when {
        err != null -> "OFFLINE" to Red
        feed == null -> "CONNECTING" to Amber
        feed.status == "LIVE" -> "LIVE" to Green
        feed.status == "OFFLINE" -> "OFFLINE" to Red
        feed.status == "CLOSED" -> "MARKET CLOSED" to Amber
        else -> feed.status to Amber
    }
    val detail = err ?: feed?.error ?: feed?.let { (it.source ?: "") + (it.note?.let { n -> " — $n" } ?: "") +
        "  •  updated " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(it.updated)) } ?: ""
    Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column { Text("STOCKPULSE", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp, fontSize = 17.sp); Text("India intraday signals", color = Muted, fontSize = 11.sp) }
        Text("● $label", color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
    if (detail.isNotEmpty()) Text(detail, color = if (err != null) Red else Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
}

@Composable fun IndexRow(n: Idx?, b: Idx?) = Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    IndexCard("NIFTY 50", n, Modifier.weight(1f)); IndexCard("BANK NIFTY", b, Modifier.weight(1f))
}

@Composable fun IndexCard(name: String, x: Idx?, m: Modifier) {
    Card(m, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(12.dp)) {
        Text(name, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        if (x == null) { Text("—", fontSize = 20.sp, fontWeight = FontWeight.Bold); return@Column }
        val ch = x.v - x.o; val up = ch >= 0; val col = if (up) Green else Red
        Text("%,.2f".format(x.v), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("${if (up) "▲" else "▼"} %,.2f (%.2f%%)".format(abs(ch), abs(ch / x.o * 100)), color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spark(x.h, col)
    } }
}

@Composable fun Spark(h: List<Double>, col: Color) {
    if (h.size < 2) return
    Canvas(Modifier.fillMaxWidth().height(30.dp).padding(top = 6.dp)) {
        val lo = h.min(); val span = (h.max() - lo).takeIf { it > 0 } ?: 1.0
        val path = Path()
        h.forEachIndexed { i, v ->
            val pt = Offset(size.width * i / (h.size - 1), (size.height - ((v - lo) / span * size.height * 0.9f)).toFloat())
            if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
        }
        drawPath(path, col, style = Stroke(width = 3f))
    }
}

@Composable fun Bias(n: Idx?) {
    if (n == null) return
    val up = n.v >= n.o
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(10.dp)) {
        Text("Market bias: ${if (up) "bullish" else "bearish"}. Nifty is ${if (up) "above" else "below"} the previous close, so ${if (up) "buy" else "sell"} setups have the market behind them.",
            Modifier.padding(12.dp), color = Muted, fontSize = 12.5.sp)
    }
}

@Composable fun SignalCard(x: Signal) {
    var open by remember { mutableStateOf(false) }
    val buy = x.d == "BUY"; val col = if (buy) Green else Red
    val rr = abs(x.t - x.e) / abs(x.e - x.sl); val diff = (x.p - x.e) / x.e * 100
    Card(Modifier.fillMaxWidth().clickable { open = !open }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text(x.s, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("NSE • 5 min", color = Muted, fontSize = 11.sp) }
                Text(x.d, color = col, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("₹%.2f".format(x.p), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${if (diff >= 0) "▲" else "▼"} %.2f%% vs entry".format(abs(diff)), color = if (diff >= 0) Green else Red, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                V("Entry", "₹%.2f".format(x.e)); V("Stop loss", "₹%.2f".format(x.sl)); V("Target", "₹%.2f".format(x.t))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("R:R 1:%.1f".format(rr), color = Muted, fontSize = 12.sp); Text("Score ${x.sc}", color = Muted, fontSize = 12.sp)
                LinearProgressIndicator({ x.sc / 100f }, Modifier.weight(1f), color = Blue, trackColor = Line)
            }
            Text(if (open) "Hide" else "Why this ${x.d.lowercase()}?", color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            if (open) Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                x.w.forEach { Text("✓  $it", fontSize = 12.5.sp) }
                Text("Invalid if price closes beyond the stop (₹%.2f).".format(x.sl), color = Muted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable fun V(a: String, b: String) = Column { Text(a, color = Muted, fontSize = 10.5.sp); Text(b, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
